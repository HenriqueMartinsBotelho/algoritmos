print("Juros simples e composto")

C = input("Digite o Capital: ")
I = input("Digite a Taxa de Juros: ")
t = input("Digite o tempo: ")


res = float(C)*float(I)*float(t)



print("Valor Final: {0}".format(res))

