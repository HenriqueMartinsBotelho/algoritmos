print("Juros simples e composto")

C = input("Digite o Capital: ")
I = input("Digite a Taxa de Juros: ")
T = input("Digite o Tempo: ") 

Ress = float(C)*float(I)*float(T)

print("Valor Final: {0}" .format(Ress))
