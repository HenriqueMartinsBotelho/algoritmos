n1 = float(input("Digite o n1: \n"))
n2 = float(input("Digite o n2: \n"))

soma = n1 + n2

print("resultado:",soma)
