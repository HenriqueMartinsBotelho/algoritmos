lado = int(input("Digite o lado do quadrado: \n"))

#eu que dei o nome de lado
#int = inteiro
#input como se fosse o escreva em portugol

perimetro = lado*4
area = lado * lado

print("perimetro: \n", perimetro)
print("area: \n", area)

