raio = float(input("valor do raio: \n"))

import math
area = math.pi*raio**2

print("valor da area:", area)

