base = int(input("valor da base: \n"))
altura = int(input("valor da altura: \n"))

perimetro = base*2 + altura*2
area = base*altura

print("perimetro: \n", perimetro)
print("area: \n", area)
