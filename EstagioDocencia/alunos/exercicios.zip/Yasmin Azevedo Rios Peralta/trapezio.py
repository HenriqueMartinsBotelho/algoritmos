#trapezio

bm = int(input("valor da base menor: \n"))
bM = int(input("valor da base maior: \n"))
h = int(input("valor da base altura: \n"))

area = ((bM+bm)*h)/2

print("area: ", area)
