#area do triangulo 

base = int(input("digite o valor da base: \n"))
altura = int(input("digite o valor da altura: \n"))

area = (base*altura)/2

print("area: ", area)



