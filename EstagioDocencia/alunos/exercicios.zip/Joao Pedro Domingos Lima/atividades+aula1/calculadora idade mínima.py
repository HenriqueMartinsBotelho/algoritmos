idade = input("Qual sua idade?") 
idade1 = float(idade)/2
sum = float(idade1) + 7
print ("Idade minima das meninas que você pode pegar é: {0}" .format (sum))



