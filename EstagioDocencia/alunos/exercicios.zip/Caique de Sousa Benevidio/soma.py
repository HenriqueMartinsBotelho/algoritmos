#!/usr/bin/env python

################################### Soma #######################################

number1 = float(input("Dê o primeiro número!\n"))
number2 = float(input("Dê o segundo número\n"))

sum3 = number1 + number2

print("A soma é: " + str(round(sum3, 2)))
