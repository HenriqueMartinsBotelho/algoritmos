def somaQ(n):
  soma = 0
  for i in range(1,n+1):
    soma=soma+i
  return soma

print(somaQ(12))