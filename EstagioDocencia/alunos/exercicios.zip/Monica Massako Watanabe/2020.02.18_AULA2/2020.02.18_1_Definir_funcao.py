def imprime_apresentacao():
  print("Bem-vindo a disciplina")
  print("Processamento da Informa��o")
  print("UFABC")

imprime_apresentacao()
    

#

def imprime_apresentacao(x):
  print("Bem-vindo a disciplina")
  print("Processamento da Informa��o")
  print("UFABC")
  print(x)

imprime_apresentacao(2020)