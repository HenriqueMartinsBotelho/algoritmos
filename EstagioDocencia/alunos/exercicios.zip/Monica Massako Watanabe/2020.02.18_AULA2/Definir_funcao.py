w=40

p=60

w==5*8
Out[8]: True

w==5*8+1
Out[9]: False

w+p==100
Out[11]: True

#

 def imprime_apresentacao():
    print("Bem-vindo a disciplina")
    print("Processamento da Informa��o")
    print("UFABC")


# 