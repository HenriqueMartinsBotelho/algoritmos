import math

n = int( input( "entre com um numero: "))
print("o fatorial é: {0}".format(math.factorial(n)))
